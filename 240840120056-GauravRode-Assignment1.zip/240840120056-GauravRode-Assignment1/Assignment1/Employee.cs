﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    internal class Employee
    {
        private int empNo;
        public int EmpNo
        {
            get { return empNo; }
            set
            {
                if (value > 0  )
                    empNo = value;
                else
                    Console.WriteLine("Invalid emp no");
            }
        }

        private string name;
        public string Name
        {
            get { return name; }
            set
            {
                if (value != "" && value!=null)
                    name = value;
                else
                    Console.WriteLine("Invalid name");
            }
        }

        private decimal basic;
        public decimal Basic
        {
            get { return basic; }
            set
            {
                if (value > 10000 && value < 1000000)
                    basic = value;
                else
                    Console.WriteLine("Invalid basic salary");
            }
        }

        private short deptNo;
        public short DeptNo
        {
            get { return deptNo; }
            set
            {
                if (value > 0)
                    deptNo = value;
                else
                    Console.WriteLine("Invalid Dept No.");
            }
        }

        public Decimal getNetSalary()
        {
            return (Basic * 1.5M) - 10000;
        }

        public Employee(int empNo=1, string name = "default", decimal basic=15000,short deptNo=1)
        {
            //this.name = name; if we do thsi validations will not get applied
            this.EmpNo = empNo;
            this.Name = name;
            this.Basic = basic;
            this.DeptNo = deptNo;
        }

        //public Employee() first preference to this ctor 
        //{
        //    this.DeptNo = 10;
        //}

        public override string ToString()
        {
            return "Emp No.="+EmpNo+", Name="+Name+", Basic Salary="+Basic+", Dept No.="+deptNo;
        }

    }
}
