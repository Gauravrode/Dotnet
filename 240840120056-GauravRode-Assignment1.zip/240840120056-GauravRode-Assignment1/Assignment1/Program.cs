﻿namespace Assignment1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee(1,"Amol",123456,10);
            Employee emp1 = new Employee(2,"",123456,0);
            Employee emp2= new Employee(3,"Shravan",100);
            Employee emp3 = new Employee(4);
            Employee emp4 = new Employee();

            Console.WriteLine("Emp sal: "+emp.getNetSalary());
            Console.WriteLine(emp);
            Console.WriteLine("Emp1 sal: "+emp1.getNetSalary());
            Console.WriteLine(emp1);//printing 0 dept no aa default value
            Console.WriteLine("Emp2 sal: "+emp2.getNetSalary());
            Console.WriteLine(emp2);
            Console.WriteLine("Emp3 sal: "+emp3.getNetSalary());
            Console.WriteLine(emp3);
            Console.WriteLine("Emp4 sal: "+emp4.getNetSalary());
            Console.WriteLine(emp4);
        }
    }
}
